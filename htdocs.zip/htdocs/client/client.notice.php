<?php

# Publicar noticia

// Importamos variables

$error = "";
$god = "";


if(isset($_POST['publish']))
{

	// Llamamos al error luego de pulsar boton

	$error = "";
	$god = "";

	// Encriptamos la informacion

	$title_notice = $_POST['title'];
	$description_notice = $_POST['description'];

	$title_encrypt = mysqli_real_escape_string($connect, $title_notice);
	$description_encrypt = mysqli_real_escape_string($connect, $description_notice);

	// Campos

	if(isset($title_encrypt) && isset($description_encrypt))
	{

		// Comprobamos si los campos estan vacios

		if(empty($title_encrypt) || empty($description_encrypt))
		{
            $error = '<div class="error">No dejes espacios vacios</div>';
		}else
        {
            $reguser = mysqli_query($connect, "INSERT INTO notices (title,description,fecha) VALUES ('$title_encrypt','$description_encrypt', now())");

            $god = '<div class="success">La noticia fue publicada</div>';
        }
}
}

?>