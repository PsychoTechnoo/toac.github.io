<?php 

# Login de usuario

// Importamos variable

	$notificacion = "";

if(isset($_POST['login']))
{
	// Importamos variable

	$notificacion = "";

	// Creamos variables para los inputs

	$email = $_POST['email'];
	$password = $_POST['password'];

	// Damos seguridad

	$email_encrypt = htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $email)));
	$password_encrypt = htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $password)));

	// Seleccionamos usuario y verificamos la contraseña

	$queryUser = "SELECT * FROM users WHERE email = '$email_encrypt'";
	$connectUser = (mysqli_query($connect, $queryUser));
	$rowUser = mysqli_fetch_assoc($connectUser);

	if(empty($rowUser['email']) && empty($rowUser['password']))
	{
		$notificacion = '<div class="error">Email y/o contraseña incorrectos</div>';
	}else
	{
		$pass = $rowUser['password'];
		if(password_verify($password_encrypt, $pass))
		{
			$_SESSION['id'] = $rowUser['id'];
			$_SESSION['username'] = $rowUser['username'];
			$_SESSION['password'] = $rowUser['password'];
			$_SESSION['email'] = $rowUser['email'];
			$_SESSION['rank'] = $rowUser['rank'];
			$_SESSION['date'] = $rowUser['date'];
			$_SESSION['img'] = $rowUser['img'];
			$_SESSION['biography'] = $rowUser['biography'];
			header("Location: /account/home/");
		}else
		{
			$notificacion = '<div class="error">Email y/o contraseña incorrectos</div>';
		}
	}



}
 ?>