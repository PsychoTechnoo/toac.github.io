<?php 

# Login de usuario

// Importamos variable

	$notificacion = "";

if(isset($_POST['change']))
{
	// Importamos variable

	$notificacion = "";

	// Creamos variables para los inputs

	$password = $_POST['password'];
	$new_password = $_POST['new-password'];

	// Damos seguridad


	$password_encrypt = htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $password)));
	$new_password_encrypt = htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $new_password)));

	// Encrypt New Password

	$bcrypt_password = password_hash($new_password_encrypt, PASSWORD_BCRYPT);

	// Seleccionamos usuario y verificamos la contraseña

	$queryUser = "SELECT * FROM users WHERE email = '$_SESSION[email]'";
	$connectUser = (mysqli_query($connect, $queryUser));
	$rowUser = mysqli_fetch_assoc($connectUser);

	if(empty($rowUser['email']) && empty($rowUser['password']))
	{
		$notificacion = '<div class="error">¡OPS! Contraseña incorrecta</div>';
	}else
	{
		$pass = $rowUser['password'];
		if(password_verify($password_encrypt, $pass))
		{
			$sqls = "UPDATE users SET password = '".$bcrypt_password."' WHERE id = '".$_SESSION['id']."'";
                $godeto = mysqli_query($connect, $sqls);
                if($godeto)
                {
                    $notificacion = '<div class="success">Contraseña cambiada correctamente</div>';
                    header("refresh:1.5; url= ../logout.php");
		}else
		{
			$notificacion = '<div class="error">¡OPS! Contraseña incorrecta</div>';
		}
	}else
	{
		$notificacion = '<div class="error">¡OPS! Contraseña incorrecta</div>';
	}



}
}
 ?>