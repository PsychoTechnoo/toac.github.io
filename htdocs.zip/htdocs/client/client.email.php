<?php


$error = "";
$god = "";

# Cambiar Email

if(isset($_POST['change']))
{

    // Abrimos error

    $error = "";
    $god = "";

    // Agarramos variables

    $email = $_POST['email'];
    $new_email = $_POST['new-email'];

    // Encriptamos los datos

    $email_encrypt =  htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $email)));
    $new_email_encrypt =  htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $new_email)));


    if(isset($email_encrypt) || isset($new_email_encrypt))
    {

        // Seleccionamos el mail

        $GetMail = mysqli_query($connect, "SELECT * FROM users WHERE email = '$email_encrypt'");

        // Campos vacios

        if(empty($new_email_encrypt))
        {
            $error = '<div class="error">No dejes espacios vacios</div>';
        }else
{
                $sqls = "UPDATE users SET email = '".$new_email_encrypt."' WHERE id = '".$_SESSION['id']."'";
                $godeto = mysqli_query($connect, $sqls);
                if($godeto)
                {
                    $god = '<div class="success">Correo electrónico cambiado correctamente</div>';
                    $godines = '<div class="success">Se cerrará tu sesión, vuelve a entrar</div>';
                    header("refresh:3; url= ../../logout.php");
                }else
                {
                    $error = '<div class="error">No se cambió el correo electrónico</div>';
                }
            }



    }
}
?>