<?php

# Registro de usuarios

// Importamos variables

$notificacion = "";

if(isset($_POST['register']))
{

	// Llamamos al error luego de pulsar boton

	$notificacion = "";

	// Encriptamos la informacion

	$username = $_POST['username'];
	$email = $_POST['email'];
	$password = $_POST['password'];
	$re_password = $_POST['re-password'];

	$username_encrypt =  htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $username)));
	$email_encrypt = htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $email)));
	$password_encrypt = htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $password)));
	$re_password_encrypt = htmlspecialchars(addslashes(mysqli_real_escape_string($connect, $re_password)));

	// Encriptamos la contraseña

	$pass_encrypt = password_hash($password_encrypt, PASSWORD_BCRYPT);
	$re_pass_encrypt = password_hash($re_password_encrypt, PASSWORD_BCRYPT);

	// img perfil

	$img = "";

	// Campos

	if(isset($username_encrypt) && isset($email_encrypt) && isset($password_encrypt) && isset($re_password_encrypt))
	{
		// Variables para usuario y email si ya estan en uso

		$GetUser = mysqli_query($connect, "SELECT * FROM users WHERE username = '$username_encrypt'");
		$GetMail = mysqli_query($connect, "SELECT * FROM users WHERE email = '$email_encrypt'");

		// Comprobamos si los campos estan vacios

		if(empty($username_encrypt) || empty($email_encrypt) || empty($password_encrypt || empty($re_password_encrypt)))
		{
            $notificacion = '<div class="error">No dejes espacios vacios</div>';
		}
		// Comprobamos si ya existe el usuario
		elseif(mysqli_num_rows($GetUser) > 0)
		{
			$notificacion = '<div class="error">El nombre de usuario ya está en uso</div>';
		}
		// Comprobamos si el mail ya está en uso
		elseif(mysqli_num_rows($GetMail) > 0)
		{
			$notificacion = '<div class="error">El email ya está en uso</div>';
		}
		// Comprobamos si las contraseñas son iguales
		elseif($password_encrypt !== $re_password_encrypt)
		{
			$notificacion = '<div class="error">Las contraseñas no son iguales</div>';
		}else
        {


            $reguser = mysqli_query($connect, "INSERT INTO users (username,rank,email,password,img,biography,date) VALUES ('$username_encrypt','1','$email_encrypt','$pass_encrypt','$cms[perfil]','Prueba de biografia. Version Beta',now())");

            $notificacion = '<div class="success">Tu registro fue completado correctamente</div>';
        }
}
}

?>