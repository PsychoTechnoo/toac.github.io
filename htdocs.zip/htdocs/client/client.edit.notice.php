<?php


$error = "";
$god = "";

# Cambiar Email

if(isset($_POST['borrar']))
{

    // Abrimos error

    $error = "";
    $god = "";

    // Agarramos variables

    $id_notice_edit = $rew['id'];
    $description_edit = $rew['description'];

    if(isset($email_encrypt) || isset($new_email_encrypt))
    {


        // Campos vacios

        if(empty($new_email_encrypt))
        {
            $error = '<div class="error">No dejes espacios vacios</div>';
        }else
{
                $sqls = "DELETE users SET title = '".$new_email_encrypt."' AND description = '".$new_email_encrypt."' WHERE id = '".$_SESSION['id']."'";
                $godeto = mysqli_query($connect, $sqls);
                if($godeto)
                {
                    $god = '<div class="success">Correo electrónico cambiado correctamente</div>';
                    $godines = '<div class="success">Se cerrará tu sesión, vuelve a entrar</div>';
                    header("refresh:3; url= ../../logout.php");
                }else
                {
                    $error = '<div class="error">No se cambió el correo electrónico</div>';
                }
            }



    }
}
?>