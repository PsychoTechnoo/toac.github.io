<?php 

// Configuracion de la web

$cms = array(

		'name' => 'Bytom',
		'link' => 'http://localhost',
		'perfil' => 'https://toac.000webhostapp.com/complements/images/user-default.png'

);

 ?>