
        <nav>
            <ul>
                <li><a href="<?php echo $cms['link']; ?>">INICIO</a></li>
                <li><a href="#">ACERCA DE</a></li>
                <li><a href="<?php echo $cms['link']; ?>/users/register">REGISTRARME</a></li>
                <li><a href="<?php echo $cms['link']; ?>/users/login">INICIAR SESIÓN</a></li>
            </ul>
        </nav>