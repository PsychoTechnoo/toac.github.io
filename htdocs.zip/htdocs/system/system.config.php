<?php 

// Eliminamos errores de PHP

error_reporting(0);


// Configuracion

$config = array(

		'host' => 'localhost',
		'user' => 'root',
		'password' => '58568750',
		'database' => 'local'

);

// Conexion

$connect = new mysqli("$config[host]", "$config[user]", "$config[password]", "$config[database]");
$connect->set_charset("utf-8");

// Verificacion

if($connect->connect_errno)
{
	die('<b style="font-family: Verdana; font-size: 50px; color: red; padding: 2rem;">PROBLEMAS DE CONEXION</b>');
}


 ?>