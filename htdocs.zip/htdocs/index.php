<?php
session_start();

# Importamos archivos necesarios

require 'client/client.cms.php';
require 'system/system.config.php';

# Verificamos sesion

if(isset($_SESSION['username']) && !empty($_SESSION['username'])){
    header("Location: /account/home");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Un lugar para expresarse - <?php echo $cms['name']; ?></title>
    <link rel="stylesheet" href="src/css/main.css">
    <link rel="shortcut icon" href="src/images/favicon.ico" type="image/x-icon">
</head>
<body>


    <!-- Header -->

    <header>

        <!-- Logo -->

        <div id="logo">
            <a href="#" class="logo"><?php echo $cms['name']; ?></a>
        </div>

        <!-- Nav -->

        <?php include('src/nav/nav.php'); ?>


    </header>

    <!-- Section 1 -->

    <section id="section">
        <label for="section" class="section-label">Te damos la bienvenida</label>
    </section>

    <!-- Section 2 -->

    <section id="section-2">
        <div id="section-2-div">
            <label for="section-2-div" class="section-2-label">¿qué es <?php echo $cms['name']; ?>?</label>
            <p class="section-2-p">
                Es una red social donde puedes transmitir en directo, contactar con tus amigos, publicar imágenes y escribir lo que piensas.
            </p>
        </div>
    </section>

    <hr class="hr-separation">

        <!-- Cards -->

        <div id="cards">

            <!-- Card 1 -->

            <div id="card">
                <label for="card-1" class="card-label">TRANSMITÍ</label>
                <p class="card-text">
                    Inicia una transmición en vivo jugando videojuegos o charlando con tu público. Muéstrale al mundo diferentes lugares y crea multistreaming con tus amigos. Tú decides.
                </p>
            </div>

             <!-- Card 2 -->

             <div id="card">
                <label for="card-1" class="card-label">CONTÁCTATE</label>
                <p class="card-text">
                    Chatea con tus amigos o con diferentes personas que formen parte de la comunidad. Crea pequeños o grandes grupos para hablar sobre diferentes temas de la actualidad.
                </p>
            </div>

            <!-- Card 3 -->

            <div id="card">
                <label for="card-1" class="card-label">PUBLICÁ</label>
                <p class="card-text">
                    Sube imágenes, fragmentos de tus streamings, escribe lo que piensas. Crea nuevos temas de conversación o únete a los ya existentes.
                    <br>
                    Se tú mismo.
                </p>
            </div>



        </div>

        <!-- Separation -->

        <div id="separation">
            <label for="separation" class="spn-label">¿qué estas esperando?</label>
            <a href="<?php echo $cms['link']; ?>/users/register" class="spn-btn">crear cuenta</a>
        </div>

       

        <hr class="hr-separation">

        <!-- Footer -->

        <footer>

            
            <!-- Footer Logo & Info -->

            <div id="ftr-logo">
                <text class="ftr-logo">bytom</text>
                <p class="ftr-p">© 2022</p>
            </div>

            <hr class="ftr-hr">

            <!-- Links -->

            <div id="links">
                <a href="" class="ftr-link">política de privacidad</a>
                <a href="" class="ftr-link">reportar un problema</a>
                <a href="" class="ftr-link">política de cookies</a>
                <a href="mailto:tomasfabbre@outlook.com" class="ftr-link">contacto</a>
            </div>

        </footer>
        





</body>
</html>