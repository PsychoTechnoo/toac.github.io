<?php
session_start();

# Importamos archivos necesarios

require '../../system/system.config.php';
require '../../client/client.cms.php';
require '../../client/client.register.php';

# Verificamos sesion

if(isset($_SESSION['username']) && !empty($_SESSION['username'])){
    header("Location: /account/home/");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Crear una cuenta - <?php echo $cms['name']; ?></title>
    <link rel="stylesheet" href="<?php echo $cms['link']; ?>/src/css/main-register.css">
    <link rel="shortcut icon" href="<?php echo $cms['link']; ?>/src/images/favicon.ico" type="image/x-icon">
</head>
<body>

    <!-- Header -->

    <header>

        <!-- Logo -->

        <div id="logo">
            <a href="#" class="logo"><?php echo $cms['name']; ?></a>
        </div>

        <!-- Nav -->

        <?php include('../../src/nav/nav.php'); ?>


    </header>

    <!-- Section 1 -->

    <section id="section">
        <label for="section" class="section-label">Crear una cuenta</label>
    </section>

    <!-- Notification -->

    <?php echo $notificacion; ?>

    <!-- Register Form -->

    <div id="register">
        <form action="" method="POST">

            <label for="register" class="reg-label">Ingresa tus datos</label>

            <!-- Input Email -->
            <input type="email" name="email" id="email" class="reg-input" placeholder="Ingrese un correo electrónico">
            <!-- Input Username -->
            <input type="text" name="username" id="username" class="reg-input" placeholder="Ingrese un nombre de usuario" minlength="4" maxlength="14">
            <!-- Input Password -->
            <input type="password" name="password" id="password" class="reg-input" placeholder="Ingrese una contraseña segura" minlength="8" maxlength="16">
            <!-- Input RePassword -->
            <input type="password" name="re-password" id="re-password" class="reg-input" placeholder="Repita la contraseña ingresada" minlength="8" maxlength="16">
            <!-- Go! -->
            <input type="submit" value="registrarme *" class="reg-btn" name="register">

        </form>
    </div>

    <p class="p-terms">* Al registrarte, aceptas las <a href="" class="a-terms">políticas de privacidad y condiciones de uso</a>.</p>

    <hr class="hr-separation">

        <!-- Footer -->

        <footer>

            
            <!-- Footer Logo & Info -->

            <div id="ftr-logo">
                <text class="ftr-logo">bytom</text>
                <p class="ftr-p">© 2022</p>
            </div>

            <hr class="ftr-hr">

            <!-- Links -->

            <div id="links">
                <a href="" class="ftr-link">política de privacidad</a>
                <a href="" class="ftr-link">reportar un problema</a>
                <a href="mailto:tomasfabbre@outlook.com" class="ftr-link">contacto</a>
            </div>

        </footer>



</body>
</html>