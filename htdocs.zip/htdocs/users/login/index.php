<?php
session_start();

# Importamos archivos necesarios

require '../../system/system.config.php';
require '../../client/client.cms.php';
require '../../client/client.login.php';

# Verificamos sesion

if(isset($_SESSION['username']) && !empty($_SESSION['username'])){
    header("Location: ../../account/home");
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title> Iniciar Sesión - <?php echo $cms['name']; ?></title>
    <link rel="stylesheet" href="<?php echo $cms['link']; ?>/src/css/main-login.css">
    <link rel="shortcut icon" href="<?php echo $cms['link']; ?>/src/images/favicon.ico" type="image/x-icon">
</head>
<body>

    <!-- Header -->

    <header>

        <!-- Logo -->

        <div id="logo">
            <a href="#" class="logo"><?php echo $cms['name']; ?></a>
        </div>

        <!-- Nav -->

        <?php include('../../src/nav/nav.php'); ?>


    </header>

    <!-- Section 1 -->

    <section id="section">
        <label for="section" class="section-label">Iniciar Sesión</label>
    </section>

    <!-- Notification -->

    <?php echo $notificacion; ?>
    

    <!-- Login Form -->

    <div id="login">
        <form action="" method="POST">

            <label for="login" class="login-label">Ingresa tus datos</label>

            <!-- Input Email -->
            <input type="email" name="email" id="email" class="login-input" placeholder="Ingresa tu correo electrónico">
            <!-- Input Password -->
            <input type="password" name="password" id="password" class="login-input" placeholder="Ingresa tu contraseña">
            <!-- Go! -->
            <input type="submit" value="ingresar" class="login-btn" name="login">

        </form>
    </div>

    <hr class="hr-separation">

        <!-- Footer -->

        <footer>

            
            <!-- Footer Logo & Info -->

            <div id="ftr-logo">
                <text class="ftr-logo">bytom</text>
                <p class="ftr-p">© 2022</p>
            </div>

            <hr class="ftr-hr">

            <!-- Links -->

            <div id="links">
                <a href="" class="ftr-link">política de privacidad</a>
                <a href="" class="ftr-link">reportar un problema</a>
                <a href="mailto:tomasfabbre@outlook.com" class="ftr-link">contacto</a>
            </div>

        </footer>



</body>
</html>