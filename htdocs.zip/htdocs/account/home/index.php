<?php
session_start();

require '../../system/system.config.php';
require '../../client/client.cms.php';

# Session Home
if(isset($_SESSION['username']) && !empty($_SESSION['username'])){

    $username = $_SESSION['username'];
    
    $get_datos_usuario = mysqli_query($connect, "SELECT * FROM `users` WHERE username = '$username'");
    $datosUsuario =  mysqli_fetch_assoc($get_datos_usuario);

}else{
    header('Location: logout.php');
exit;
}


?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>LOGUEADO! <?php echo $_SESSION['username']; ?></title>
</head>
<body>

    <a href="<?php echo $_SESSION['link']; ?>/account/home/logout.php">SALIR PERRO!</a>
    
</body>
</html>